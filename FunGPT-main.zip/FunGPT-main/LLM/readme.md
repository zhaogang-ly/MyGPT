models supported：
- internlm/internlm2_5-7b-chat
