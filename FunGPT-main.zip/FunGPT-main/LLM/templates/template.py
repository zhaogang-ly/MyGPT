import os
import sys

class Template:
    KUA_GENERATE_DATA_TEMPLATE = """xxx"""
    DUI_GENERATE_DATA_TEMPLATE = """xxx"""
    TOPIC_GENERATE_DATA_TEMPLATE = """xxx"""
    Dui_TOPIC_GENERATE_DATA_TEMPLATE = """xxx"""